package pieritz.prince.dockermessageserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerMessageServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
