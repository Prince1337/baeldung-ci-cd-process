package pieritz.prince.Docker.Product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
