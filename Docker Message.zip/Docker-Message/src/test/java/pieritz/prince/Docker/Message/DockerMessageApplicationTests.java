package pieritz.prince.Docker.Message;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerMessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
