package pieritz.prince.Docker.Message;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerMessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerMessageApplication.class, args);
	}

}
